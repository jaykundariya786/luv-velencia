require('dotenv').config();
const app = require('./server');

const PORT = process.env.PORT || 5001;
const HOST = '0.0.0.0';

app.listen(PORT, HOST, () => {
  console.log(`🚀 LV Backend server is running on http://${HOST}:${PORT}`);
  console.log(`📱 API Base URL: http://${HOST}:${PORT}/api`);
  console.log(`🏥 Health Check: http://${HOST}:${PORT}/api/health`);
});