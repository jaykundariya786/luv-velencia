import { createServer, Server } from "http";
import { Express } from "express";
import { setupBackendProxy } from "./proxy";

export async function registerRoutes(app: Express): Promise<Server> {
  const server = createServer(app);

  // Health check endpoint
  app.get('/health', async (req, res) => {
    try {
      // Check LV Backend health
      const backendResponse = await fetch('http://localhost:5001/api/health').catch(() => null);
      const backendStatus = backendResponse?.ok ? 'OK' : 'DOWN';

      res.json({
        status: 'OK',
        message: 'Main server is running',
        timestamp: new Date().toISOString(),
        services: {
          mainServer: 'OK',
          lvBackend: backendStatus,
          proxy: 'OK'
        },
        endpoints: {
          clientAPI: '/lv-api/*',
          adminAPI: '/api/*',
          lvBackendDirect: 'http://localhost:5001/api/*'
        }
      });
    } catch (error) {
      res.status(500).json({
        status: 'ERROR',
        message: 'Health check failed',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  });

  // NOTE: Proxy setup is handled in server/index.ts before routes are registered
  // This ensures proxy middleware runs before any catch-all routes

  return server;
}