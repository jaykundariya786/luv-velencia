import { createProxyMiddleware } from 'http-proxy-middleware';
import { Express } from 'express';

export function setupBackendProxy(app: Express) {
  console.log('Setting up backend proxy to LV Backend on port 5001');

  // Proxy /lv-api requests to LV Backend (client uses /lv-api)
  app.use('/lv-api', createProxyMiddleware({
    target: 'http://localhost:5001',
    changeOrigin: true,
    ws: true,
    secure: false,
    pathRewrite: {
      '^/lv-api': '/api'
    },
    onError: (err, req, res) => {
      console.error('Proxy error for /lv-api:', err);
      res.status(500).json({ success: false, message: 'Backend service unavailable' });
    },
    onProxyReq: (proxyReq, req, res) => {
      console.log(`[PROXY] ${req.method} /lv-api${req.url} -> /api${req.url}`);
    }
  }));

  // Proxy /api requests to LV Backend (admin panel uses /api)
  app.use('/api', createProxyMiddleware({
    target: 'http://localhost:5001',
    changeOrigin: true,
    ws: true,
    secure: false,
    onError: (err, req, res) => {
      console.error('Proxy error for /api:', err);
      res.status(500).json({ success: false, message: 'Backend service unavailable' });
    },
    onProxyReq: (proxyReq, req, res) => {
      console.log(`[PROXY] ${req.method} /api${req.url} -> /api${req.url}`);
    }
  }));

  // Proxy admin panel requests to admin server
  app.use('/admin', createProxyMiddleware({
    target: 'http://localhost:5174',
    changeOrigin: true,
    pathRewrite: {
      '^/admin': ''
    }
  }));

  // Handle preflight requests for CORS
  app.options('/api/*', (req, res) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS,PATCH');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
    res.sendStatus(200);
  });
}