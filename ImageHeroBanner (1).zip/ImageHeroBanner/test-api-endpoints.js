
const API_BASE = 'http://localhost:5000';

async function testEndpoint(endpoint, method = 'GET', body = null, headers = {}) {
  try {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };

    if (body) {
      options.body = JSON.stringify(body);
    }

    const response = await fetch(`${API_BASE}${endpoint}`, options);
    const data = await response.json().catch(() => null);

    const status = response.ok ? '✅' : '❌';
    console.log(`${status} ${method} ${endpoint}: ${response.status}`);
    
    return { success: response.ok, data, status: response.status };
  } catch (error) {
    console.log(`❌ ${method} ${endpoint}: Error - ${error.message}`);
    return { success: false, error: error.message };
  }
}

async function runAPITests() {
  console.log('🚀 Testing LUV VALENCIA API Endpoints...\n');

  // Test health check
  console.log('--- HEALTH CHECK ---');
  await testEndpoint('/health');

  // Test client API endpoints (via /lv-api proxy)
  console.log('\n--- CLIENT API ENDPOINTS (/lv-api) ---');
  
  // Products
  await testEndpoint('/lv-api/products');
  await testEndpoint('/lv-api/products/featured');
  await testEndpoint('/lv-api/products/bestsellers');
  await testEndpoint('/lv-api/products/new-arrivals');
  await testEndpoint('/lv-api/products/search?q=shoes');
  
  // Categories
  await testEndpoint('/lv-api/categories');
  await testEndpoint('/lv-api/categories/tree');
  
  // Cart (requires auth)
  await testEndpoint('/lv-api/cart');
  await testEndpoint('/lv-api/wishlist');

  // Test admin API endpoints (via /api proxy)
  console.log('\n--- ADMIN API ENDPOINTS (/api) ---');
  
  // Admin dashboard
  await testEndpoint('/api/admin/dashboard');
  await testEndpoint('/api/admin/users');
  await testEndpoint('/api/admin/products');
  await testEndpoint('/api/admin/analytics');
  
  // Orders
  await testEndpoint('/api/orders');
  await testEndpoint('/api/orders/admin/statistics');
  
  // Analytics
  await testEndpoint('/api/analytics/overview');
  await testEndpoint('/api/analytics/sales-chart');
  await testEndpoint('/api/analytics/top-products');
  await testEndpoint('/api/analytics/category-performance');
  await testEndpoint('/api/analytics/customer-insights');

  // Test authentication endpoints
  console.log('\n--- AUTHENTICATION ENDPOINTS ---');
  await testEndpoint('/lv-api/auth/me');
  await testEndpoint('/api/auth/me');

  console.log('\n✨ API Testing Complete!');
  console.log('\n📝 Note: Some endpoints may return 401 (Unauthorized) as they require authentication.');
  console.log('🔗 All endpoints should now be properly routed through the proxy server.');
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { runAPITests, testEndpoint };
}

// Run if executed directly
if (require.main === module) {
  runAPITests();
}
