// This file previously contained static JSON data.
// All data has been moved to API endpoints and is now fetched dynamically.
// 
// Converted to APIs:
// - data_materials -> /api/materials-care
// - Size guide data -> /api/size-guide/:category
// - Search suggestions -> /api/search-suggestions
// - Account menu items -> /api/account-menu
//
// This file can be removed once all imports are updated.
