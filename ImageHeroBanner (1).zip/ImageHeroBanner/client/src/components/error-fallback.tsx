
import { AlertCircle, RefreshCw, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface ErrorFallbackProps {
  error?: string;
  onRetry?: () => void;
  onGoHome?: () => void;
  title?: string;
  description?: string;
  showHomeButton?: boolean;
}

export default function ErrorFallback({
  error = "Something went wrong",
  onRetry,
  onGoHome,
  title = "Oops! Something went wrong",
  description = "We're having trouble loading this page. Please try again.",
  showHomeButton = true
}: ErrorFallbackProps) {
  return (
    <div className="min-h-[400px] flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="pt-6">
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>{title}</AlertTitle>
            <AlertDescription className="mt-2">
              {description}
              {error && (
                <div className="mt-2 text-xs opacity-75 font-mono bg-gray-100 p-2 rounded">
                  {error}
                </div>
              )}
            </AlertDescription>
          </Alert>
          
          <div className="flex flex-col gap-3">
            {onRetry && (
              <Button onClick={onRetry} className="w-full" variant="default">
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            )}
            
            {showHomeButton && onGoHome && (
              <Button onClick={onGoHome} className="w-full" variant="outline">
                <Home className="w-4 h-4 mr-2" />
                Go Home
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
