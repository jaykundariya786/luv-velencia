
import { useQuery } from '@tanstack/react-query';
import { fetchSizeGuide } from '@/store/slices/utilitySlice';

export const useSizeGuide = (category: string) => {
  return useQuery({
    queryKey: ['sizeGuide', category],
    queryFn: async () => {
      const result = await fetchSizeGuide(category);
      return result.payload;
    },
    enabled: !!category,
    staleTime: 1000 * 60 * 60, // 1 hour
  });
};
