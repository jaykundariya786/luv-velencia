
import { useQuery } from '@tanstack/react-query';
import { fetchSearchSuggestions } from '@/store/slices/utilitySlice';

export const useSearchSuggestions = (query?: string) => {
  return useQuery({
    queryKey: ['searchSuggestions', query],
    queryFn: async () => {
      const result = await fetchSearchSuggestions(query);
      return result.payload;
    },
    enabled: !!query,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
};
