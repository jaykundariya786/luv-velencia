import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { fetchProducts, fetchProductBySlug, fetchFeaturedProducts, fetchBestsellerProducts, fetchNewArrivals, searchProducts } from '@/store/slices/productsSlice';
import { useEffect } from 'react';

export const useProducts = (params?: any) => {
  const dispatch = useAppDispatch();
  const { products, isLoading, error, filters } = useAppSelector((state) => state.products);

  useEffect(() => {
    dispatch(fetchProducts(params || {}));
  }, [dispatch, params]);

  return {
    products,
    isLoading,
    error,
    filters,
    refetch: () => dispatch(fetchProducts(params || {})),
  };
};

export const useProduct = (slug: string) => {
  const dispatch = useAppDispatch();
  const { currentProduct, isLoading, error } = useAppSelector((state) => state.products);

  useEffect(() => {
    if (slug) {
      dispatch(fetchProductBySlug(slug));
    }
  }, [dispatch, slug]);

  return {
    product: currentProduct,
    isLoading,
    error,
    refetch: () => dispatch(fetchProductBySlug(slug)),
  };
};

export const useFeaturedProducts = () => {
  const dispatch = useAppDispatch();
  const { featuredProducts, isLoading, error } = useAppSelector((state) => state.products);

  useEffect(() => {
    dispatch(fetchFeaturedProducts());
  }, [dispatch]);

  return {
    products: featuredProducts,
    isLoading,
    error,
    refetch: () => dispatch(fetchFeaturedProducts()),
  };
};

export const useBestsellerProducts = () => {
  const dispatch = useAppDispatch();
  const { bestsellerProducts, isLoading, error } = useAppSelector((state) => state.products);

  useEffect(() => {
    dispatch(fetchBestsellerProducts());
  }, [dispatch]);

  return {
    products: bestsellerProducts,
    isLoading,
    error,
    refetch: () => dispatch(fetchBestsellerProducts()),
  };
};

export const useNewArrivals = () => {
  const dispatch = useAppDispatch();
  const { newArrivals, isLoading, error } = useAppSelector((state) => state.products);

  useEffect(() => {
    dispatch(fetchNewArrivals());
  }, [dispatch]);

  return {
    products: newArrivals,
    isLoading,
    error,
    refetch: () => dispatch(fetchNewArrivals()),
  };
};

export const useSearchProducts = (query: string) => {
  const dispatch = useAppDispatch();
  const { searchResults, isLoading, error } = useAppSelector((state) => state.products);

  useEffect(() => {
    if (query) {
      dispatch(searchProducts(query));
    }
  }, [dispatch, query]);

  return {
    products: searchResults,
    isLoading,
    error,
    refetch: () => dispatch(searchProducts(query)),
  };
};

export const useRecentlyViewed = () => {
  const { recentlyViewed, isLoading, error } = useAppSelector((state) => state.products);

  return {
    products: recentlyViewed || [],
    isLoading,
    error,
  };
};