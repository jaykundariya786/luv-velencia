import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { fetchAccountMenu } from '@/store/slices/utilitySlice';
import { useEffect } from 'react';

export const useAccountMenu = () => {
  const dispatch = useAppDispatch();
  const { accountMenu, isLoading, error } = useAppSelector((state) => state.utility);

  useEffect(() => {
    if (!accountMenu) {
      dispatch(fetchAccountMenu());
    }
  }, [dispatch, accountMenu]);

  return {
    data: accountMenu,
    isLoading,
    error,
    refetch: () => dispatch(fetchAccountMenu()),
  };
};