
import { useQuery } from '@tanstack/react-query';
import { fetchMaterialsCare } from '@/store/slices/utilitySlice';

export const useMaterialsCare = () => {
  return useQuery({
    queryKey: ['materialsCare'],
    queryFn: async () => {
      const result = await fetchMaterialsCare();
      return result.payload;
    },
    staleTime: 1000 * 60 * 60, // 1 hour
  });
};
