import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import categoriesReducer from './slices/categoriesSlice';
import cartReducer from './slices/cartSlice';
import wishlistReducer from './slices/wishlistSlice';
import ordersReducer from './slices/ordersSlice';
import userReducer from './slices/userSlice';
import utilityReducer from './slices/utilitySlice';
import shoppingBagReducer from './slices/shoppingBagSlice';
import productsReducer from './slices/productsSlice';
import uploadReducer from './slices/uploadSlice';
import apiReducer from './slices/apiSlice';
import notificationReducer from './slices/notificationSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    shoppingBag: shoppingBagReducer,
    categories: categoriesReducer,
    cart: cartReducer,
    wishlist: wishlistReducer,
    orders: ordersReducer,
    user: userReducer,
    utility: utilityReducer,
    products: productsReducer,
    upload: uploadReducer,
    api: apiReducer,
    notifications: notificationReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ['persist/PERSIST'],
      },
    }),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;