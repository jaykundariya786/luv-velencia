import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Error handling utility
const handleApiError = (error: any) => {
  if (error.response) {
    return error.response.data?.message || `Server error: ${error.response.status}`;
  } else if (error.request) {
    return 'Network error: Unable to connect to server';
  } else {
    return error.message || 'An unexpected error occurred';
  }
};

interface ProductVariant {
  _id: string;
  sku: string;
  size: string;
  color: string;
  stock: number;
  price: number;
  images: string[];
}

interface Product {
  _id: string;
  name: string;
  description: string;
  slug: string;
  price: number;
  category: string;
  subcategory?: string;
  brand: string;
  images: string[];
  variants: ProductVariant[];
  tags: string[];
  featured: boolean;
  bestseller: boolean;
  newArrival: boolean;
  rating: number;
  reviewCount: number;
  status: 'active' | 'inactive' | 'out_of_stock';
  createdAt: string;
  updatedAt: string;
}

interface FilterData {
  total: number;
  categories: { [key: string]: number };
  lines: { [key: string]: number };
  colors: string[];
  materials: string[];
}

interface ProductsState {
  products: Product[];
  currentProduct: Product | null;
  featuredProducts: Product[];
  bestsellerProducts: Product[];
  newArrivals: Product[];
  searchResults: Product[];
  recentlyViewed: Product[];
  filters: FilterData;
  isLoading: boolean;
  error: string | null;
  totalPages: number;
  currentPage: number;
}

const initialState: ProductsState = {
  products: [],
  currentProduct: null,
  featuredProducts: [],
  bestsellerProducts: [],
  newArrivals: [],
  searchResults: [],
  recentlyViewed: [],
  filters: {
    total: 0,
    categories: {},
    lines: {},
    colors: [],
    materials: []
  },
  isLoading: false,
  error: null,
  totalPages: 0,
  currentPage: 1,
};

// API base URL
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://0.0.0.0:5001/api';

// Configure axios
axios.defaults.withCredentials = true;
axios.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Async thunks for API calls
export const fetchProducts = createAsyncThunk(
  'products/fetchProducts',
  async (params = {}, { rejectWithValue }) => {
    try {
      const queryString = new URLSearchParams(params as Record<string, string>).toString();
      const url = `${API_BASE_URL}/products${queryString ? `?${queryString}` : ''}`;
      const response = await axios.get(url);
      
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch products');
    } catch (error: any) {
      const errorMessage = handleApiError(error);
      console.error('Fetch products error:', errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const searchProducts = createAsyncThunk(
  'products/searchProducts',
  async (query: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/products/search`, {
        params: { q: query }
      });
      
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to search products');
    } catch (error: any) {
      const errorMessage = handleApiError(error);
      console.error('Search products error:', errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const fetchFeaturedProducts = createAsyncThunk(
  'products/fetchFeaturedProducts',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/products/featured`);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch featured products');
    } catch (error: any) {
      const errorMessage = handleApiError(error);
      console.error('Fetch featured products error:', errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const fetchBestsellerProducts = createAsyncThunk(
  'products/fetchBestsellerProducts',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/products/bestsellers`);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch bestseller products');
    } catch (error: any) {
      const errorMessage = handleApiError(error);
      console.error('Fetch bestseller products error:', errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const fetchNewArrivals = createAsyncThunk(
  'products/fetchNewArrivals',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/products/new-arrivals`);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch new arrivals');
    } catch (error: any) {
      const errorMessage = handleApiError(error);
      console.error('Fetch new arrivals error:', errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const fetchProductBySlug = createAsyncThunk(
  'products/fetchProductBySlug',
  async (slug: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/products/${slug}`);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch product');
    } catch (error: any) {
      const errorMessage = handleApiError(error);
      console.error('Fetch product by slug error:', errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const addProductReview = createAsyncThunk(
  'products/addProductReview',
  async ({ productId, reviewData }: { productId: string; reviewData: any }, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/products/${productId}/reviews`, reviewData);
      if (response.data.success) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to add product review');
    } catch (error: any) {
      const errorMessage = handleApiError(error);
      console.error('Add product review error:', errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

const productsSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    clearCurrentProduct: (state) => {
      state.currentProduct = null;
    },
    clearProducts: (state) => {
      state.products = [];
      state.totalPages = 0;
      state.currentPage = 1;
    },
    clearError: (state) => {
      state.error = null;
    },
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    clearSearchResults: (state) => {
      state.searchResults = [];
    },
    addToRecentlyViewed: (state, action) => {
      const product = action.payload;
      state.recentlyViewed = state.recentlyViewed.filter(p => p._id !== product._id);
      state.recentlyViewed.unshift(product);
      if (state.recentlyViewed.length > 10) {
        state.recentlyViewed = state.recentlyViewed.slice(0, 10);
      }
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch products
      .addCase(fetchProducts.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.isLoading = false;
        state.products = action.payload.products || action.payload;
        state.totalPages = action.payload.totalPages || 1;
        state.currentPage = action.payload.currentPage || 1;
        state.filters = action.payload.filters || state.filters;
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Search products
      .addCase(searchProducts.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(searchProducts.fulfilled, (state, action) => {
        state.isLoading = false;
        state.searchResults = action.payload.products || action.payload;
        state.totalPages = action.payload.totalPages || 1;
        state.currentPage = action.payload.currentPage || 1;
      })
      .addCase(searchProducts.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch featured products
      .addCase(fetchFeaturedProducts.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchFeaturedProducts.fulfilled, (state, action) => {
        state.isLoading = false;
        state.featuredProducts = action.payload;
      })
      .addCase(fetchFeaturedProducts.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch bestseller products
      .addCase(fetchBestsellerProducts.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchBestsellerProducts.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bestsellerProducts = action.payload;
      })
      .addCase(fetchBestsellerProducts.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch new arrivals
      .addCase(fetchNewArrivals.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchNewArrivals.fulfilled, (state, action) => {
        state.isLoading = false;
        state.newArrivals = action.payload;
      })
      .addCase(fetchNewArrivals.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch product by slug
      .addCase(fetchProductBySlug.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchProductBySlug.fulfilled, (state, action) => {
        state.isLoading = false;
        state.currentProduct = action.payload;
      })
      .addCase(fetchProductBySlug.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Add product review
      .addCase(addProductReview.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(addProductReview.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(addProductReview.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearCurrentProduct, clearProducts, clearError, setCurrentPage, clearSearchResults, addToRecentlyViewed } = productsSlice.actions;
export default productsSlice.reducer;