
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

interface UploadState {
  isUploading: boolean;
  uploadProgress: number;
  uploadedUrls: string[];
  error: string | null;
}

const initialState: UploadState = {
  isUploading: false,
  uploadProgress: 0,
  uploadedUrls: [],
  error: null,
};

// API base URL
const API_BASE_URL = import.meta.env.VITE_API_URL || '/lv-api';

// Configure axios
axios.defaults.withCredentials = true;
axios.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Async thunks for API calls
export const uploadImage = createAsyncThunk(
  'upload/uploadImage',
  async (file: File, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      formData.append('image', file);

      const response = await axios.post(`${API_BASE_URL}/upload/image`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.data.success && response.data.data) {
        return response.data.data.url;
      }
      throw new Error(response.data.message || 'Failed to upload image');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to upload image');
    }
  }
);

export const uploadImages = createAsyncThunk(
  'upload/uploadImages',
  async (files: File[], { rejectWithValue }) => {
    try {
      const formData = new FormData();
      files.forEach((file) => {
        formData.append('images', file);
      });

      const response = await axios.post(`${API_BASE_URL}/upload/images`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.data.success && response.data.data) {
        return response.data.data.urls;
      }
      throw new Error(response.data.message || 'Failed to upload images');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to upload images');
    }
  }
);

const uploadSlice = createSlice({
  name: 'upload',
  initialState,
  reducers: {
    clearUploadedUrls: (state) => {
      state.uploadedUrls = [];
    },
    clearError: (state) => {
      state.error = null;
    },
    resetUploadState: (state) => {
      state.isUploading = false;
      state.uploadProgress = 0;
      state.uploadedUrls = [];
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Upload single image
      .addCase(uploadImage.pending, (state) => {
        state.isUploading = true;
        state.uploadProgress = 0;
        state.error = null;
      })
      .addCase(uploadImage.fulfilled, (state, action) => {
        state.isUploading = false;
        state.uploadProgress = 100;
        state.uploadedUrls.push(action.payload);
      })
      .addCase(uploadImage.rejected, (state, action) => {
        state.isUploading = false;
        state.uploadProgress = 0;
        state.error = action.payload as string;
      })
      // Upload multiple images
      .addCase(uploadImages.pending, (state) => {
        state.isUploading = true;
        state.uploadProgress = 0;
        state.error = null;
      })
      .addCase(uploadImages.fulfilled, (state, action) => {
        state.isUploading = false;
        state.uploadProgress = 100;
        state.uploadedUrls = [...state.uploadedUrls, ...action.payload];
      })
      .addCase(uploadImages.rejected, (state, action) => {
        state.isUploading = false;
        state.uploadProgress = 0;
        state.error = action.payload as string;
      });
  },
});

export const { clearUploadedUrls, clearError, resetUploadState } = uploadSlice.actions;
export default uploadSlice.reducer;
