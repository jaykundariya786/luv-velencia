import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Error handling utility
const handleApiError = (error: any) => {
  if (error.response) {
    return error.response.data?.message || `Server error: ${error.response.status}`;
  } else if (error.request) {
    return 'Network error: Unable to connect to server';
  } else {
    return error.message || 'An unexpected error occurred';
  }
};

interface UtilityState {
  searchSuggestions: any[];
  accountMenu: any;
  materialsCare: any;
  sizeGuides: { [category: string]: any };
  isLoading: boolean;
  error: string | null;
}

const initialState: UtilityState = {
  searchSuggestions: [],
  accountMenu: null,
  materialsCare: null,
  sizeGuides: {},
  isLoading: false,
  error: null,
};

// API base URL
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://0.0.0.0:5001/api';

// Configure axios
axios.defaults.withCredentials = true;
axios.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Async thunks for API calls
export const fetchSearchSuggestions = createAsyncThunk(
  'utility/fetchSearchSuggestions',
  async (query: string = '', { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${API_BASE_URL}/utility/search-suggestions`,
        { params: query ? { q: query } : {} }
      );
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch search suggestions');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to fetch search suggestions');
    }
  }
);

export const fetchAccountMenu = createAsyncThunk(
  'utility/fetchAccountMenu',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/utility/account-menu`);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch account menu');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to fetch account menu');
    }
  }
);

export const fetchMaterialsCare = createAsyncThunk(
  'utility/fetchMaterialsCare',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/utility/materials-care`);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch materials care');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to fetch materials care');
    }
  }
);

export const fetchSizeGuide = createAsyncThunk(
  'utility/fetchSizeGuide',
  async (category: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/utility/size-guide/${category}`);
      if (response.data.success && response.data.data) {
        return { category, data: response.data.data };
      }
      throw new Error(response.data.message || 'Failed to fetch size guide');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to fetch size guide');
    }
  }
);

const utilitySlice = createSlice({
  name: 'utility',
  initialState,
  reducers: {
    clearSearchSuggestions: (state) => {
      state.searchSuggestions = [];
    },
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch search suggestions
      .addCase(fetchSearchSuggestions.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchSearchSuggestions.fulfilled, (state, action) => {
        state.isLoading = false;
        state.searchSuggestions = action.payload;
      })
      .addCase(fetchSearchSuggestions.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch account menu
      .addCase(fetchAccountMenu.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchAccountMenu.fulfilled, (state, action) => {
        state.isLoading = false;
        state.accountMenu = action.payload;
      })
      .addCase(fetchAccountMenu.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch materials care
      .addCase(fetchMaterialsCare.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchMaterialsCare.fulfilled, (state, action) => {
        state.isLoading = false;
        state.materialsCare = action.payload;
      })
      .addCase(fetchMaterialsCare.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch size guide
      .addCase(fetchSizeGuide.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchSizeGuide.fulfilled, (state, action) => {
        state.isLoading = false;
        state.sizeGuides[action.payload.category] = action.payload.data;
      })
      .addCase(fetchSizeGuide.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearSearchSuggestions, clearError } = utilitySlice.actions;
export default utilitySlice.reducer;