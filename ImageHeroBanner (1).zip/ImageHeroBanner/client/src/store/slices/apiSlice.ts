
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Error handling utility
const handleApiError = (error: any) => {
  if (error.response) {
    return error.response.data?.message || `Server error: ${error.response.status}`;
  } else if (error.request) {
    return 'Network error: Unable to connect to server';
  } else {
    return error.message || 'An unexpected error occurred';
  }
};

// API base URL
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://0.0.0.0:5001/api';

// Configure axios
axios.defaults.withCredentials = true;
axios.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

interface ApiState {
  isLoading: boolean;
  error: string | null;
  contactMessages: any[];
  subscriptionPlans: any[];
  newsletterStatus: string | null;
  appointmentStatus: string | null;
}

const initialState: ApiState = {
  isLoading: false,
  error: null,
  contactMessages: [],
  subscriptionPlans: [],
  newsletterStatus: null,
  appointmentStatus: null,
};

// Contact form submission
export const submitContactForm = createAsyncThunk(
  'api/submitContactForm',
  async (formData: any, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/contact`, formData);
      if (response.data.success) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to submit contact form');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to submit contact form');
    }
  }
);

// Newsletter subscription
export const subscribeToNewsletter = createAsyncThunk(
  'api/subscribeToNewsletter',
  async (email: string, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/newsletter/subscribe`, { email });
      if (response.data.success) {
        return response.data.message;
      }
      throw new Error(response.data.message || 'Failed to subscribe to newsletter');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to subscribe to newsletter');
    }
  }
);

// Book appointment
export const bookAppointment = createAsyncThunk(
  'api/bookAppointment',
  async (appointmentData: any, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/appointments`, appointmentData);
      if (response.data.success) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to book appointment');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to book appointment');
    }
  }
);

// Fetch subscription plans
export const fetchSubscriptionPlans = createAsyncThunk(
  'api/fetchSubscriptionPlans',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/subscription/plans`);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch subscription plans');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to fetch subscription plans');
    }
  }
);

// Subscribe to plan
export const subscribeToPlan = createAsyncThunk(
  'api/subscribeToPlan',
  async (subscriptionData: any, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/subscription/subscribe`, subscriptionData);
      if (response.data.success) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to subscribe to plan');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to subscribe to plan');
    }
  }
);

// Fetch user appointments
export const fetchUserAppointments = createAsyncThunk(
  'api/fetchUserAppointments',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/appointments/user`);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch appointments');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to fetch appointments');
    }
  }
);

// Send support message
export const sendSupportMessage = createAsyncThunk(
  'api/sendSupportMessage',
  async (messageData: any, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/support`, messageData);
      if (response.data.success) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to send support message');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to send support message');
    }
  }
);

// Fetch FAQ
export const fetchFAQ = createAsyncThunk(
  'api/fetchFAQ',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/utility/faq`);
      if (response.data.success && response.data.data) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to fetch FAQ');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to fetch FAQ');
    }
  }
);

// Apply discount code
export const applyDiscountCode = createAsyncThunk(
  'api/applyDiscountCode',
  async (discountCode: string, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/discounts/apply`, { code: discountCode });
      if (response.data.success) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to apply discount code');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to apply discount code');
    }
  }
);

// Process payment
export const processPayment = createAsyncThunk(
  'api/processPayment',
  async (paymentData: any, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/payments/process`, paymentData);
      if (response.data.success) {
        return response.data.data;
      }
      throw new Error(response.data.message || 'Failed to process payment');
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || error.message || 'Failed to process payment');
    }
  }
);

const apiSlice = createSlice({
  name: 'api',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    clearNewsletterStatus: (state) => {
      state.newsletterStatus = null;
    },
    clearAppointmentStatus: (state) => {
      state.appointmentStatus = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Submit contact form
      .addCase(submitContactForm.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(submitContactForm.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(submitContactForm.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Newsletter subscription
      .addCase(subscribeToNewsletter.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(subscribeToNewsletter.fulfilled, (state, action) => {
        state.isLoading = false;
        state.newsletterStatus = action.payload;
      })
      .addCase(subscribeToNewsletter.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Book appointment
      .addCase(bookAppointment.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(bookAppointment.fulfilled, (state, action) => {
        state.isLoading = false;
        state.appointmentStatus = 'success';
      })
      .addCase(bookAppointment.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch subscription plans
      .addCase(fetchSubscriptionPlans.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchSubscriptionPlans.fulfilled, (state, action) => {
        state.isLoading = false;
        state.subscriptionPlans = action.payload;
      })
      .addCase(fetchSubscriptionPlans.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Subscribe to plan
      .addCase(subscribeToPlan.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(subscribeToPlan.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(subscribeToPlan.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch user appointments
      .addCase(fetchUserAppointments.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchUserAppointments.fulfilled, (state, action) => {
        state.isLoading = false;
      })
      .addCase(fetchUserAppointments.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Send support message
      .addCase(sendSupportMessage.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(sendSupportMessage.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(sendSupportMessage.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Fetch FAQ
      .addCase(fetchFAQ.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchFAQ.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(fetchFAQ.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Apply discount code
      .addCase(applyDiscountCode.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(applyDiscountCode.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(applyDiscountCode.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Process payment
      .addCase(processPayment.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(processPayment.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(processPayment.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearError, clearNewsletterStatus, clearAppointmentStatus } = apiSlice.actions;
export default apiSlice.reducer;
