const { spawn } = require('child_process');
const path = require('path');

console.log('🚀 Starting LUV VALENCIA E-commerce System');
console.log('=====================================');

// Start LV Backend (MongoDB + Express API)
console.log('📊 Starting LV Backend API on port 5001...');
const backend = spawn('npm', ['start'], {
  cwd: path.join(__dirname, 'LV Backend'),
  stdio: 'inherit',
  env: {
    ...process.env,
    PORT: '5001',
    NODE_ENV: 'development'
  }
});

// Start Admin Panel (React Admin Dashboard)
console.log('🔧 Starting Admin Panel on port 5174...');
const admin = spawn('npm', ['run', 'dev'], {
  cwd: path.join(__dirname, 'admin'),
  stdio: 'inherit',
  env: {
    ...process.env,
    PORT: '5174',
    VITE_API_URL: 'http://localhost:5001/api'
  }
});

// Start Main Client (Customer Frontend)
console.log('🛍️ Starting Main Client on port 5000...');
const client = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  env: {
    ...process.env,
    PORT: '5000',
    API_URL: 'http://localhost:5001/api'
  }
});

// Handle process exits
backend.on('close', (code) => {
  console.log(`LV Backend exited with code ${code}`);
});

admin.on('close', (code) => {
  console.log(`Admin Panel exited with code ${code}`);
});

client.on('close', (code) => {
  console.log(`Main Client exited with code ${code}`);
});

// Handle errors
backend.on('error', (err) => {
  console.error('Failed to start LV Backend:', err);
});

admin.on('error', (err) => {
  console.error('Failed to start Admin Panel:', err);
});

client.on('error', (err) => {
  console.error('Failed to start Main Client:', err);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🔄 Shutting down all services...');
  backend.kill();
  admin.kill();
  client.kill();
  process.exit(0);
});

console.log('\n🌐 Access URLs:');
console.log('Main Store: http://localhost:5000');
console.log('Admin Panel: http://localhost:5000/admin');
console.log('Backend API: http://localhost:5001/api');
console.log('Direct Admin: http://localhost:5174');